namespace WebGoatCore.Data
{
    public static class Constants
    {
        public const string WEBGOAT_ROOT = "WEBGOAT_ROOT";
    }
}